//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PV.rc
//
#define IDD_ABOUTBOX                    100
#define IDI_PV                          100
#define IDI_PICTURE                     101
#define IDI_TOOLBAR_BMP                 102
#define IDD_OPTIONS_DIALOG              131
#define IDI_TIFF                        139
#define IDI_IFF                         140
#define IDI_JPG                         141
#define IDI_PCD                         142
#define IDI_PCX                         143
#define IDI_PNG                         144
#define IDI_PSD                         145
#define IDI_TGA                         146
#define IDI_BMP                         147
#define IDD_KEY_HELP                    148
#define IDC_RECENT_FILES                1015
#define IDC_TIME                        1019
#define IDC_KEYS                        1020
#define IDC_FUNCTIONS                   1021
#define IDC_NAME                        1022
#define IDC_COPYRIGHT_MESSAGE           1023
#define IDC_VERSION                     1024
#define IDC_FREEIMAGE_VERSION           1025
#define IDC_WIDTH                       1026
#define IDC_HEIGHT                      1027
#define IDC_ASPECT                      1028
#define IDC_CENTRE                      1029
#define IDC_JPEG_SUPERB                 1030
#define IDC_JPEG_GOOD                   1031
#define IDC_JPEG_NORMAL                 1032
#define IDC_JPEG_AVERAGE                1033
#define IDC_JPEG_BAD                    1034
#define IDC_TIFF_PACKBITS               1035
#define IDC_TIFF_DEFLATE                1036
#define IDC_LEFT                        1037
#define IDC_TOP                         1038
#define IDC_BMP_RLE                     1039
#define IDC_BMP_NONE                    1040
#define IDC_ENLARGE                     1041
#define IDC_TIFF_LZW                    1042
#define IDC_TIFF_NONE                   1043
#define IDC_RIGHT                       1044
#define IDC_BOTTOM                      1045
#define IDC_PRELOAD                     1046
#define IDC_INSTANCES                   1047
#define ID_ICON                         65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
