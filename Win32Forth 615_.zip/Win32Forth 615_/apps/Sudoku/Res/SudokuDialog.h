//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SudokuDialog.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_HELP                        148
#define IDD_IMPORT                      158
#define IDC_SUDOKU_EDIT                 1004
#define IDC_FILE                        1005
#define IDC_HELP_TEXT                   1006
#define IDC_IMPORT_TEXT                 1007
#define IDC_KEYS                        1020
#define IDC_ACTIONS                     1021
#define IDC_NAME                        1022
#define IDC_FACTS                       1023
#define IDC_VERSION                     1024
#define IDC_RULES                       1025
#define ID_ICON                         65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        159
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
