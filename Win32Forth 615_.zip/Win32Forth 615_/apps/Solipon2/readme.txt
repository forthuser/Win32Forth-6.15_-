\ bruno GAUTHIER
\ vendredi, avril 01 2005 - 16:11
\ SOLIPION 2.0
\ Classic Morpion Solitaire Like Game
\ We place the 5 th pawn on a line in any directions like xxxx0 OR x0xxx etc
\ Then a line is drawn.
\ The program controls if we can place a Pawn (or dot) here or there.
\ If for a particulare place they are severals lines that could be drawns then
\ the prog shows each, one after one, with yellow color in a loop.
\ So to choose one of them, just click and the program will  draw this one.
\ If we want to undo, just click on the "to last move" button in the toobar.
\ 
\ The goal is to draw a maximum of lines.
\ The principe of the game is simple but that is not so easy to beat 100 lines.
\ The actual best published record is 170 lines !! Amazing :)
\ 
\ They are a zoom in the toolbar to adjust the board as we want :)
\ Solipion seems to cheat with the scores :)
\ In fact if Solipion found a move to play after my, our last move, then he place it,
\ then his name also in the score (if of course that is a good score) 
\
\ I go back to play now :)
\ 


To add a Pawn to draw a line, 4 Pawns in the same direction must already exist.
We can use only one pawn of an already line drawn.
Solipion, controls if we follow the rules.
Any direction is possible, vertical, horizontal or diagonally.

links : http://croix2malte.free.fr/indexGB.php
http://euler.free.fr/morpion.htm

New in version 2.01:
Labels on left and up of the board. 
Visible only if the board is pushed right and down with the keys:<shift +right> and <shift +down>.
Zoom key: <ctrlt +right> for a better view. Use <ctrlt +left> for shrinking.
