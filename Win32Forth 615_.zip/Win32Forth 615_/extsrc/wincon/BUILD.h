// precompiler input to load windows constants

// required predefined values
#define WINVER       0x0501
#define _WIN32_IE    0x0501
#define _WIN32_WINNT 0x0501
#ifndef _WIN32
	#define _WIN32
#endif

#include <windows.h>
#include <commctrl.h>
#include <richedit.h>
#include <zmouse.h>
#include <vfw.h>
#include <shlwapi.h>

