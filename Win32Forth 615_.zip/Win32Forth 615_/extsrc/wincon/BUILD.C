// precompiler input to load windows constants

// required predefined values
#include "Build.h"
