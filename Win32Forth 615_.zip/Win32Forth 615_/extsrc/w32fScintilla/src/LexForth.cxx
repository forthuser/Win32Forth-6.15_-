// Scintilla source code edit control
/** @file LexForth.cxx
 ** Lexer to use with Win32Forth
 **/
// Copyright 1998-2001 by Neil Hodgson <neilh@scintilla.org>
// The License.txt file describes the conditions under which this
// software may be distributed.

// Mostly rewritten 12.6.2004 by Dirk Busch

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdarg.h>

#include "Platform.h"

#include "PropSet.h"
#include "Accessor.h"
#include "KeyWords.h"
#include "Scintilla.h"
#include "SciLexer.h"
#include "StyleContext.h"

#define SCE_FORTH_DEFAULT  0
#define SCE_FORTH_COMMENT  1
#define SCE_FORTH_STRING   2
#define SCE_FORTH_NUMBER   3
#define SCE_FORTH_LOCALS   4
#define SCE_FORTH_ANS      5
#define SCE_FORTH_USER1    6
#define SCE_FORTH_USER2    7
#define SCE_FORTH_USER3    8
#define SCE_FORTH_USER4    9
#define SCE_FORTH_USER5   10
#define SCE_FORTH_USER6   11

inline bool is_blank(int ch)
{
	if( ch == ' ' || ch == '\t' )
		return true;
	return false;
}

inline bool is_eol(char ch)
{
	if( ch == '\r' || ch == '\n' )
		return true;
	return false;
}

inline bool is_whitespace(int ch)
{
	if( is_blank(ch) || is_eol(ch) )
		return true;
	return false;
}

// #define FORTH_DEBUG
#ifdef FORTH_DEBUG
static FILE *f_debug;
#define log(x)  fputs(f_debug,x);
#else
#define log(x)
#endif

#define BL ' '

static Accessor *st = NULL;
static unsigned int cur_pos = 0, pos1 = 0, pos2 = 0, pos0 = 0, lengthDoc = 0;
static char *buffer = NULL;

char getChar(bool is_bl)
{
    char ch=st->SafeGetCharAt(cur_pos);
    if(is_bl) if(is_whitespace(ch)) ch=BL;
    return ch;
}

char getCharBL()
{
    char ch=st->SafeGetCharAt(cur_pos);
    return ch;
}

int parse(char ch, bool skip_eol)
{
// pos1 - start pos of word
// pos2 - pos after of word
// pos0 - start pos

	 buffer[0] = 0;

    char c=0;
    int len;
    bool is_bl=ch==BL;
    pos0=pos1=pos2=cur_pos;
    for( ;cur_pos<lengthDoc && (c=getChar(is_bl))==ch; cur_pos++ )
	 {
        if(is_eol(c) && !skip_eol)
		  {
            pos2=pos1;
            return 0;
        }
    }
    pos1=cur_pos;
    pos2=pos1;
    if( cur_pos==lengthDoc )
		 return 0;
    for( len=0;cur_pos<lengthDoc && (c=getChar(is_bl))!=ch; cur_pos++)
	 {
        if( is_eol(c) && !skip_eol )
			  break;
        pos2++;
        buffer[len++]=c;
    }
    if(c==ch)
		 pos2--;
    buffer[len]='\0';
#ifdef FORTH_DEBUG
    fprintf(f_debug,"parse: %c %s\r\n",ch,buffer);
#endif
    return len;
}

bool _is_number( char *s,int base )
{
	for( bool bFirst = true; *s; s++, bFirst = false )
	{
		if( bFirst && *s == '-' || *s == '+' )
			continue;

		int digit = ((int)*s)-(int)'0';
		if( digit > 9 && base>10 )
			digit -= 7;
		if( digit < 0 )
			return false;
		if( digit >= base)
			return false;
	}
	return true;
}

bool is_number(char *s)
{
	if( *s == '$' || strncmp(s,"0X",2) == 0 )
		return _is_number(s+2, 16); // hex
	return _is_number(s, 10); // decimal
}

void ColourTo( unsigned int pos, int chAttr, Accessor &styler )
{
	if( pos < lengthDoc )
		styler.ColourTo(pos, chAttr);
}

void ColouriseForthDoc(unsigned int startPos, int length, int, WordList *keywordLists[], Accessor &styler)
{
	st        = &styler;
	cur_pos   = startPos;
	lengthDoc = startPos + length;
	
	buffer = new char[length+2];
	if( !buffer )
		return;

	char *szLastToken = new char[length+2];
	if( !szLastToken )
	{
		delete []buffer;
		return;
	}

	bool bSkipString = false;

#ifdef FORTH_DEBUG
    f_debug=fopen("c:\\sci.log","at");
#endif
	WordList &ans          = *keywordLists[0];
	WordList &commentStart = *keywordLists[1];
	WordList &commentEnd   = *keywordLists[2];
	WordList &user1        = *keywordLists[3];
	WordList &user2        = *keywordLists[4];
	WordList &user3        = *keywordLists[5];
	WordList &user4        = *keywordLists[6];
	WordList &user5        = *keywordLists[7];
	WordList &user6        = *keywordLists[8];

	char stringList[] = { ",\" Z\" Z,\" +Z,\" +Z,\" +Z\", C\" S\" .\" ABORT\" EDITOR\" BROWSE\" SHELL\" DOS\"" };
	WordList string; string.Set( stringList );

	char compileList[] = { ": ' ['] POSTPONE [DEFINED] [UNDEFINED] #IFDEF #IFNDEF" };
	WordList compile; compile.Set( compileList );

	styler.StartAt(startPos);
	styler.StartSegment(startPos);

	while( parse(BL,true)!=0 )
	{
		//-------------------------------------------------------------------------------------------
		//-------------------------------------------------------------------------------------------
		if( pos0 != pos1 )
		{
			ColourTo( pos0, SCE_FORTH_DEFAULT, styler );
			ColourTo( pos1-1,SCE_FORTH_DEFAULT, styler );
		}

		_strupr(buffer);

		//-------------------------------------------------------------------------------------------
		//-------------------------------------------------------------------------------------------
		if( strcmp("\\S",buffer)==0 ) // comment till end of file
		{
			char ch1 = styler.SafeGetCharAt(pos1-1);
			char ch2 = styler.SafeGetCharAt(pos1-2);
			char ch3 = styler.SafeGetCharAt(pos1-3);
			if( ch1 == ' ' && ch2 == ':' && is_eol(ch3) )
			{
				ColourTo( pos1, SCE_FORTH_DEFAULT, styler );
				ColourTo( pos2, SCE_FORTH_DEFAULT, styler );
				cur_pos = pos2 + 1;
			}
			else
			{
				ColourTo( pos1, SCE_FORTH_COMMENT, styler );
				ColourTo( lengthDoc-1, SCE_FORTH_COMMENT, styler );
				break; // leave parser
			}
		}
		else if( strcmp("\\",buffer)==0 || strcmp("//",buffer)==0 ) // comment till end of line
		{
			char ch1 = styler.SafeGetCharAt(pos1-1);
			char ch2 = styler.SafeGetCharAt(pos1-2);
			char ch3 = styler.SafeGetCharAt(pos1-3);
			if( ch1 == ' ' && ch2 == ':' && is_eol(ch3) )
			{
				ColourTo( pos1, SCE_FORTH_ANS, styler );
				ColourTo( pos2, SCE_FORTH_ANS, styler );
				cur_pos = pos2 + 1;
			}
			else
			{
				ColourTo( pos1-1,SCE_FORTH_COMMENT, styler );
				parse(1, false);
				ColourTo( pos2,SCE_FORTH_COMMENT, styler );
			}
		}
		else if( strcmp("(",buffer)==0 || strcmp(".(",buffer)==0 ) // comment till )
		{
			ColourTo( pos1,SCE_FORTH_COMMENT, styler );
			if( !compile.InList(szLastToken) )
			{
				parse(')', true);
				ColourTo( pos2+1,SCE_FORTH_COMMENT, styler );
			}
		}
		else if( strcmp("{",buffer)==0 ) // locals till }
		{
			char ch1 = styler.SafeGetCharAt(pos1-1);
			char ch2 = styler.SafeGetCharAt(pos1-2);
			char ch3 = styler.SafeGetCharAt(pos1-3);
			if( ch1 == ' ' && ch2 == ':' && is_eol(ch3) )
			{
				ColourTo( pos1, SCE_FORTH_DEFAULT, styler );
				ColourTo( pos2, SCE_FORTH_DEFAULT, styler );
				cur_pos = pos2 + 1;
			}
			else
			{
				ColourTo( pos1,SCE_FORTH_LOCALS, styler );
				parse('}', true);
				ColourTo( pos2+1,SCE_FORTH_LOCALS, styler );
			}
		}
		else if( commentStart.InList(buffer) ) // multi line comments
		{
			static int multiComment = 0;
			multiComment++;

			ColourTo( pos1,SCE_FORTH_COMMENT, styler );

			while( parse(BL,true) != 0 )
			{
				_strupr(buffer);

				if( commentStart.InList(buffer) )
				{
					multiComment++;
				}
				else if( commentEnd.InList(buffer) )
				{
					multiComment--;
					if( multiComment < 0 )
						multiComment = 0;

					if( !(multiComment) )
					{
						ColourTo( pos2,SCE_FORTH_COMMENT, styler );
						break;
					}
				}
			}
			multiComment = 0;
		}
		//-------------------------------------------------------------------------------------------
		//-------------------------------------------------------------------------------------------
		else if( string.InList(buffer) ) // string till "
		{
			if( bSkipString )
			{
				bSkipString = false;
				continue;
			}

			int iStart = pos1;
//			int iEnd   = pos2;

			char ch1 = styler.SafeGetCharAt(pos1-1);
			char ch2 = styler.SafeGetCharAt(pos1-2);
			char ch3 = styler.SafeGetCharAt(pos1-3);
			if( ch1 == ' ' && ch2 == ':' && is_eol(ch3) )
			{
//				if( strcmp( "ABORT\"", buffer ) == 0 || strcmp( ".\"", buffer ) == 0 )
					bSkipString = true;
				continue;
			}

			if( parse('\"', false) )
			{
				// pos2 == Position vor dem 2. " !!!
				char ch = styler.SafeGetCharAt(pos2+2); // hole das Zeichen nach dem "
				if( is_blank(ch) )
				{
					ColourTo( iStart, SCE_FORTH_STRING, styler );
					ColourTo( pos2+1, SCE_FORTH_STRING, styler );
				}
				else if( is_eol(ch) )
				{
					ColourTo( iStart, SCE_FORTH_STRING, styler );
					ColourTo( pos2+1, SCE_FORTH_STRING, styler );
					cur_pos = pos2 + 1;
				}
			}
			else
			{
				if( parse(1, false) )
					ColourTo( pos2 , SCE_FORTH_STRING, styler );
			}

		}
		//-------------------------------------------------------------------------------------------
		//-------------------------------------------------------------------------------------------
		else if( ans.InList(buffer) ) // ANS words
		{
         ColourTo( pos1,SCE_FORTH_ANS, styler );
         ColourTo( pos2,SCE_FORTH_ANS, styler );
		}
		else if( user1.InList(buffer) ) // User words
		{
         ColourTo( pos1,SCE_FORTH_USER1, styler );
         ColourTo( pos2,SCE_FORTH_USER1, styler );
		}
		else if( user2.InList(buffer) ) // User words
		{
         ColourTo( pos1,SCE_FORTH_USER2, styler );
         ColourTo( pos2,SCE_FORTH_USER2, styler );
		}
		else if( user3.InList(buffer) ) // User words
		{
         ColourTo( pos1,SCE_FORTH_USER3, styler );
         ColourTo( pos2,SCE_FORTH_USER3, styler );
		}
		else if( user4.InList(buffer) ) // User words
		{
         ColourTo( pos1,SCE_FORTH_USER4, styler );
         ColourTo( pos2,SCE_FORTH_USER4, styler );
		}
		else if( user5.InList(buffer) ) // User words
		{
         ColourTo( pos1,SCE_FORTH_USER5, styler );
         ColourTo( pos2,SCE_FORTH_USER5, styler );
		}
		else if( user6.InList(buffer) ) // User words
		{
         ColourTo( pos1,SCE_FORTH_USER6, styler );
         ColourTo( pos2,SCE_FORTH_USER6, styler );
		}
		else if( is_number(buffer) )    // numbers
		{
			ColourTo( pos1,SCE_FORTH_NUMBER, styler );
			ColourTo( pos2,SCE_FORTH_NUMBER, styler );
		}
		//-------------------------------------------------------------------------------------------
		//-------------------------------------------------------------------------------------------

		strcpy( szLastToken, buffer );
	}

#ifdef FORTH_DEBUG
    fclose(f_debug);
#endif
    delete []buffer;      buffer = NULL;
	delete []szLastToken;
    return;
}

static void FoldForthDoc(unsigned int, int, int, WordList *[], Accessor &)
{
	;
}

static const char * const forthWordLists[] =
{
	"ANS keywords",
	"multiline comment's start",
	"multiline comment's end",
	"user words 1",
	"user words 2",
	"user words 3",
	"user words 4",
	"user words 5",
	"user words 6",
	0,
};

static void ColouriseNullDoc(unsigned int startPos, int length, int, WordList *[], Accessor &styler) {
	// Null language means all style bytes are 0 so just mark the end - no need to fill in.
	if (length > 0) {
		styler.StartAt( startPos ); 
		styler.StartSegment( startPos );
		ColourTo( startPos + length - 1, 0, styler );
	}
}


LexerModule lmForth(SCLEX_FORTH, ColouriseForthDoc, "forth", FoldForthDoc,forthWordLists );
LexerModule lmNull (SCLEX_NULL , ColouriseNullDoc , "null" );
